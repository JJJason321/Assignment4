import { Injectable } from '@angular/core';
import { Fengxin } from './fengxin';
import {myInfo} from '../assets/FengxinInfo';


@Injectable({
  providedIn: 'root'
})
export class MydataService {

 constructor() { }

 loadData(): Fengxin {
   return myInfo;
 }
}
