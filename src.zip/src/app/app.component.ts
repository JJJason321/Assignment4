import { Component } from '@angular/core';

import { food } from "./food";
import breakfast from "../assets/breakfast.json";
import lunch from "../assets/lunch.json";
import dinner from "../assets/dinner.json";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  
  breakfast: food[] = breakfast.breakfast;
  lunch:food[] = lunch.lunch;
  dinner:food[]=dinner.dinner;

  title = 'fengxin-A4';



}
