import { Component, OnInit } from '@angular/core';
import {Fengxin} from '../fengxin';
import {MydataService} from '../mydata.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  myInfoes: Fengxin;

  constructor(private myInfo:MydataService) { }

  ngOnInit() {
    this.getData();
  }

  getData(){
    this.myInfoes = this.myInfo.loadData();
  }

}
