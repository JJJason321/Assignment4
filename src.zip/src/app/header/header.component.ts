import { Component, OnInit } from '@angular/core';
import {Fengxin} from '../fengxin';
import {MydataService} from '../mydata.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  myInfoes: Fengxin;

  constructor(private myInfo:MydataService) { }

  ngOnInit() {
    this.getData();
  }

  getData(){
    this.myInfoes = this.myInfo.loadData();
  }

}
