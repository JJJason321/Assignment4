export interface food {
    
    calories: string;
    name: String;
    price:string;
}