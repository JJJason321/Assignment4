export class Fengxin{
    s_number: number;
    s_name:string;
    s_loginName:string;
    s_campus:string;
    s_title:string;
}