import {Fengxin} from "../app/fengxin";

export const myInfo: Fengxin = {
    
        s_name: "Xinyu Feng",
        s_campus: "Davis",
        s_loginName:"fengxin",
        s_number: 991506158,
        s_title: "Assignment4"
       }